package edu.lanecc.tictactoe;

public enum XO {
    X, O, Empty
}
