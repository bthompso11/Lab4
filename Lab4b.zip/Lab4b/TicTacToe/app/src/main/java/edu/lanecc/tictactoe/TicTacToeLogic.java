package edu.lanecc.tictactoe;

//Imported to add random number generator for new game method.
import java.util.Random;




public class TicTacToeLogic {

    /********* Instance variables ***********/

    private String playerOName;
    private String playerXName;

    //Adding player score variables for best_Of logic
    private Integer playerOWins = 0;
    private Integer playerXWins = 0;


    // Initialize to player O
    private XO currentPlayer = XO.O;

    
    // Initialize the array so each square is empty
    private XO[] gameState = {XO.Empty, XO.Empty, XO.Empty, 
            XO.Empty, XO.Empty, XO.Empty, 
            XO.Empty, XO.Empty, XO.Empty};

    // Setters

    public void setPlayerOName(String playerOName) {
        this.playerOName = playerOName;
    }

    public void setPlayerXName(String playerXName) {
        this.playerXName = playerXName;
    }

    // Getters

    public XO getCurrentPlayer() {
        return currentPlayer;
    }

    public int getNumberOfSquares() {
        return gameState.length;
    }

    public XO[] getGameState() {
        return gameState;
}


    /********** Game-play logic *********/

    public String getCurrentPlayerName() {
        return currentPlayer == XO.O ? playerOName : playerXName;
    }

    public boolean makeMove(int position) {
        // Make sure the squre is empty
        if (gameState[position] == XO.Empty) {
            // Mark the square with an X or O
            gameState[position] = currentPlayer;
            // Switch players
            currentPlayer = (currentPlayer == XO.O) ? XO.X : XO.O;
            return true;
        }
        // The square wasn't empty
        return false;
    }
    
    public boolean winningState() {
        boolean win = false;
        // Check for each of the eight possible winning sets of X's or O's
        if(gameState[0] == currentPlayer && gameState[1] == currentPlayer && gameState[2] == currentPlayer){
            win= true;
            if (currentPlayer == XO.O){
                playerOWins += 1;
            }
            else{
                playerXWins += 1;
            }
        }
        else if(gameState[3] == currentPlayer && gameState[4] == currentPlayer && gameState[5] == currentPlayer){

            win= true;
            if (currentPlayer == XO.O){
                playerOWins += 1;
            }
            else{
                playerXWins += 1;
            }
        }
        else if(gameState[6] == currentPlayer && gameState[7] == currentPlayer && gameState[8] == currentPlayer){
            win= true;
            if (currentPlayer == XO.O){
                playerOWins += 1;
            }
            else{
                playerXWins += 1;
            }
        }
        else if(gameState[0] == currentPlayer && gameState[3] == currentPlayer && gameState[6] == currentPlayer){
            win= true;
            if (currentPlayer == XO.O){
                playerOWins += 1;
            }
            else{
                playerXWins += 1;
            }
        }
        else if(gameState[1] == currentPlayer && gameState[4] == currentPlayer && gameState[7] == currentPlayer){
            win= true;
            if (currentPlayer == XO.O){
                playerOWins += 1;
            }
            else{
                playerXWins += 1;
            }
        }
        else if(gameState[2] == currentPlayer && gameState[5] == currentPlayer && gameState[8] == currentPlayer){
            win= true;
            if (currentPlayer == XO.O){
                playerOWins += 1;
            }
            else{
                playerXWins += 1;
            }
        }
        else if(gameState[0] == currentPlayer && gameState[4] == currentPlayer && gameState[8] == currentPlayer){
            win= true;
            if (currentPlayer == XO.O){
                playerOWins += 1;
            }
            else{
                playerXWins += 1;
            }
        }
        else if(gameState[2] == currentPlayer && gameState[4] == currentPlayer && gameState[6] == currentPlayer){
            win= true;
            if (currentPlayer == XO.O){
                playerOWins += 1;
            }
            else{
                playerXWins += 1;
            }
        }
        return win;
    }

    public void newGame() {
        // Reset the squares to all be empty
        for (int i = 0 ; i<gameState.length; i++)
            gameState[i] = XO.Empty;


        // TODO: Make this random so O doesn't always start
        //Added logic to make this random when new game is started.
        Random r = new Random();
        int randNum = r.nextInt(100);

        if (randNum > 50) {
            currentPlayer = XO.O;
        }
        else{
            currentPlayer = XO.X;
        }

    }

    //Used to reset the wins after a best_Of preferences game
    public void resetWins(){
        //Reset number of wins for each player
        playerOWins = 0;
        playerXWins = 0;
    }

    public void checkTotalWins(int wins){

    }

}
