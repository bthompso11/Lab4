package edu.lanecc.tictactoe;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;






public class MainActivity extends AppCompatActivity
        implements TextView.OnEditorActionListener {

    /********** Instance variables ***********/

    // Widget object references
    EditText playerOEditText;
    EditText playerXEditText;
    Button endButton;

    //setting up preferences
    private SharedPreferences prefs;
    private boolean enableAI = false;
    private boolean enableDelay = false;
    private int bestOf = 0;

    //Constants for bestOf Choices
    private final int NO_BEST_OF = 0;
    private final int TWO_OF_THREE = 1;
    private final int THREE_OF_FIVE = 2;


    // Game logic object
    TicTacToeLogic game = new TicTacToeLogic();


    /************ Life-cycle callback methods **************/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        playerOEditText = findViewById(R.id.playerOEditText);
        playerOEditText.setOnEditorActionListener(this);
        playerXEditText = findViewById(R.id.playerXEditText);
        playerXEditText.setOnEditorActionListener(this);
        endButton = findViewById(R.id.resetButton);
        endButton.setVisibility(View.INVISIBLE);

        // setting the default values for the preferences
        PreferenceManager.setDefaultValues(this, R.xml.preferences, false);

        //getting shared preferences object
        prefs = PreferenceManager.getDefaultSharedPreferences(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.activity_menu, menu);
                return true;
    }

    /*************** Event handlers *************************/

    //This method will restart the game
    public void resetButton(View view){
        for (int i = 0 ; i < game.getNumberOfSquares(); i++) {
            ImageView imageView =
                    findViewById(R.id.constraint_layout).findViewWithTag(String.valueOf(i));
            imageView.setImageResource(0);
            endButton.setVisibility(View.INVISIBLE);
        }
        game.newGame();
    }

    @Override
    public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
        String playerName = "";
        if(i == EditorInfo.IME_ACTION_DONE ||
                i == EditorInfo.IME_ACTION_UNSPECIFIED ||
                i == EditorInfo.IME_ACTION_NEXT ||
                keyEvent.getKeyCode() == KeyEvent.KEYCODE_ENTER) {

            playerName = playerOEditText.getText().toString();
            if (playerName != "")
                game.setPlayerOName(playerName);

            playerName = playerXEditText.getText().toString();
            if (playerName != "")
                game.setPlayerXName(playerName);
        }

        // Hide the soft keyboard
        InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(textView.getWindowToken(), 0);

        return false;
    }

    @Override
    public void onResume(){
        super.onResume();

        //Getting the preferences
        enableAI = prefs.getBoolean("pref_enable_AI", false);
        enableDelay = prefs.getBoolean("pref_add_delay", false);
        bestOf = prefs.getInt("best_of", 0);

        if (enableAI) {
            //TODO: Write Logic for computer to take turn
            game.newGame();
            game.setPlayerXName("Computer");
        }
        else {
            game.newGame();
        }

        if (enableDelay){
            //TODO: Write logic to add delay between computer turns
        }
        else{
            //TODO: Write Logic to nothing happen
        }

        if (bestOf == NO_BEST_OF ){
            playerOEditText.setVisibility(View.INVISIBLE);
            playerXEditText.setVisibility(View.INVISIBLE);
            //playerOWinsEditText.setVisibility(View.INVISIBLE);

        }
        else if (bestOf == TWO_OF_THREE) {

            game.checkTotalWins(2);
        }
        else if (bestOf == THREE_OF_FIVE){
            game.checkTotalWins(3);
        }


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.menu_About:
                Toast.makeText(this, "Settings Coming Soon!",
                        Toast.LENGTH_LONG).show();
                return true;
            case R.id.menu_settings:
                startActivity(new Intent(getApplicationContext(),
                        SettingsActivity.class));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //This method to trigger the image appear when palyer click the box
    public void dropIn(View view){

        ImageView clickedView = (ImageView)view;
        int gamePosition = Integer.parseInt(clickedView.getTag().toString());
        if (game.makeMove(gamePosition)) {
            if(game.getCurrentPlayer() == XO.O) {
                // Put an O in the square
                clickedView.setImageResource(android.R.drawable.ic_delete);
            } else {
                // Put an X in the square
                clickedView.setImageResource(android.R.drawable.presence_online);
            }
            if(game.winningState()){
                endButton.setVisibility(View.VISIBLE);
                endButton.setText(game.getCurrentPlayerName() + " wins!"+"\n"+"Play again?");}
        } else {
            endButton.setVisibility(View.VISIBLE);
            endButton.setText("It is a draw"+"\n"+"Play again?");
        }
    }


}
