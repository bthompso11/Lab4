# TicTacToe

</br>This is a simple TicTacToe game for Android Device
</br>
</br>MinSDKVersion : 19
</br>Development Tool : Android Studio Library
</br>
</br>
![Screenshot](https://github.com/snufflesrea/TicTacToe/blob/master/Capture.PNG)

